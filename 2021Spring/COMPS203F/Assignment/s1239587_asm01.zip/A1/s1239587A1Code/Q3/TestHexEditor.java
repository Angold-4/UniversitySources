// TestHexEditor

import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 	// Resolve class ActionListener

public class TestHexEditor {
    public static void main(String[] args) {
        HexEditor anEditor = new HexEditor();
        anEditor.setVisible(true);
    }
}

